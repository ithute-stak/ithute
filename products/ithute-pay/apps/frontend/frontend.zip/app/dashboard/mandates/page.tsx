"use client";
import { PageHeader } from "@/components/dashboard/page-header";
import { DataTable } from "@/components/dashboard/data-table";
import { StatusBadge } from "@/components/dashboard/status-badge";
import { useAdminMandatesQuery } from "@/store/gateway-api";
export default function Page(){const {data=[],isLoading}=useAdminMandatesQuery();return <><PageHeader title="Direct debit mandates" description="Customer consent records used to support recurring and scheduled mobile-money charges."/><DataTable rows={data} empty={isLoading?"Loading mandates…":"No mandates yet."} columns={[{key:"id",label:"Mandate",render:(r:any)=><p className="font-bold text-[#082b4d]">{r.id}</p>},{key:"ref",label:"Reference",render:(r:any)=>r.reference},{key:"provider",label:"Provider",render:(r:any)=>r.provider},{key:"phone",label:"Customer",render:(r:any)=>r.phone},{key:"frequency",label:"Frequency",render:(r:any)=><span className="capitalize">{r.frequency||"—"}</span>},{key:"status",label:"Status",render:(r:any)=><StatusBadge status={r.status}/>},{key:"created",label:"Created",render:(r:any)=>new Date(r.created_at).toLocaleString()}]}/></>}
