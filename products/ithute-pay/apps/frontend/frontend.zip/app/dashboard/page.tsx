"use client";
import { Activity, ArrowDownLeft, ArrowUpRight, CircleDollarSign, Repeat2, Route } from "lucide-react";
import { PageHeader } from "@/components/dashboard/page-header";
import { StatCard } from "@/components/dashboard/stat-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useDashboardQuery, useAdminTransactionsQuery } from "@/store/gateway-api";
import { StatusBadge } from "@/components/dashboard/status-badge";

export default function DashboardPage() {
  const { data = {}, isLoading, error } = useDashboardQuery();
  const { data: tx = [] } = useAdminTransactionsQuery();
  const num=(key:string)=>isLoading?"…":String(data[key] ?? 0);
  return <><PageHeader title="Gateway overview" description="A realtime operational view of collections, payouts, provider movements and recurring payment mandates."/>
    {error && <div className="mb-5 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">Dashboard data could not be loaded.</div>}
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-6">
      <StatCard label="Collections" value={num("payments")} hint="Payment intents" icon={<ArrowDownLeft/>}/>
      <StatCard label="Payouts" value={num("payouts")} hint="Merchant disbursements" icon={<ArrowUpRight/>}/>
      <StatCard label="Transactions" value={num("transactions")} hint="Provider movements" icon={<Route/>}/>
      <StatCard label="Mandates" value={num("mandates")} hint="Recurring debit authority" icon={<Repeat2/>}/>
      <StatCard label="Succeeded" value={num("succeeded")} hint="Confirmed movements" icon={<CircleDollarSign/>}/>
      <StatCard label="Failed" value={num("failed")} hint="Needs attention" icon={<Activity/>}/>
    </div>
    <div className="mt-6 grid gap-4 xl:grid-cols-[1.35fr_.65fr]">
      <Card><CardHeader><CardTitle>Recent provider activity</CardTitle></CardHeader><CardContent><div className="space-y-2">{tx.slice(0,7).map((row:any)=><div key={row.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border bg-slate-50/60 px-4 py-3"><div><p className="text-sm font-bold text-[#082b4d]">{row.direction === "inbound" ? "Collection" : "Outbound movement"} · {row.provider}</p><p className="mt-1 text-xs text-slate-500">{row.provider_transaction_id || row.id}</p></div><div className="flex items-center gap-3"><div className="text-right"><p className="text-sm font-black">{row.currency} {row.amount}</p><p className="text-[11px] text-slate-400">{new Date(row.created_at).toLocaleString()}</p></div><StatusBadge status={row.status}/></div></div>)}{!tx.length && <p className="py-8 text-center text-sm text-slate-500">No provider activity yet.</p>}</div></CardContent></Card>
      <Card><CardHeader><CardTitle>Gateway controls</CardTitle></CardHeader><CardContent className="space-y-4 text-sm leading-6 text-slate-600"><div className="rounded-xl border border-green-200 bg-green-50 p-4"><p className="font-bold text-green-800">Financial safety</p><p className="mt-1">Idempotency prevents duplicate money movement. Unknown outcomes are reconciled before retrying.</p></div><div className="rounded-xl border border-blue-200 bg-blue-50 p-4"><p className="font-bold text-blue-800">Accounting</p><p className="mt-1">Every confirmed movement posts a balanced double-entry journal and updates merchant payable balances.</p></div><div className="rounded-xl border border-amber-200 bg-amber-50 p-4"><p className="font-bold text-amber-800">Integration</p><p className="mt-1">External systems use scoped API keys, signed webhooks and stable REST endpoints.</p></div></CardContent></Card>
    </div></>;
}
