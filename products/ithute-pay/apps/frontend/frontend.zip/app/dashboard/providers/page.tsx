"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";
import { Cable, CheckCircle2, Copy, Eye, RadioTower, ShieldCheck, X } from "lucide-react";
import { PageHeader } from "@/components/dashboard/page-header";
import { DataTable } from "@/components/dashboard/data-table";
import { StatusBadge } from "@/components/dashboard/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  useActivateProviderConfigMutation,
  useAdminProvidersQuery,
  useCreateProviderConfigMutation,
  useProviderCallbackLogsQuery,
} from "@/store/gateway-api";

const empty = {
  provider: "mpesa",
  environment: "production",
  mode: "live",
  enabled: true,
  active: false,
  base_url: "https://openapi.m-pesa.com",
  market: "vodacomLES",
  country: "LES",
  currency: "LSL",
  service_provider_code: "",
  origin: "",
  api_key: "",
  public_key: "",
  callback_url: "",
  result_url: "",
  timeout_url: "",
  redirect_url: "",
  session_activation_seconds: 30,
  request_timeout_seconds: 30,
};

export default function Page() {
  const { data: providers = [] } = useAdminProvidersQuery();
  const { data: callbacks = [] } = useProviderCallbackLogsQuery();
  const [save, { isLoading }] = useCreateProviderConfigMutation();
  const [activate, { isLoading: activating }] = useActivateProviderConfigMutation();
  const [form, setForm] = useState<any>(empty);
  const [viewingProvider, setViewingProvider] = useState<any | null>(null);

  const sandbox = useMemo(() => providers.find((x: any) => x.environment === "sandbox"), [providers]);

  useEffect(() => {
    if (!form.callback_url && sandbox) {
      setForm((current: any) => ({
        ...current,
        callback_url: sandbox.callback_url || "",
        result_url: sandbox.result_url || "",
        timeout_url: sandbox.timeout_url || "",
        redirect_url: sandbox.redirect_url || "",
      }));
    }
  }, [sandbox, form.callback_url]);

  async function submit(event: FormEvent) {
    event.preventDefault();
    await save(form).unwrap();
    setForm((current: any) => ({ ...current, api_key: "", public_key: "" }));
  }

  const copy = (value?: string) => value && navigator.clipboard.writeText(value);

  return (
    <>
      <PageHeader
        title="M-Pesa gateway configuration"
        description="One platform-owned M-Pesa merchant configuration. Sandbox defaults are seeded automatically; production credentials are entered here and can be activated without editing .env."
      />

      <div className="grid gap-5 2xl:grid-cols-[1.15fr_.85fr]">
        <div className="space-y-5">
          <DataTable
            rows={providers}
            empty="The sandbox provider configuration will be created when the backend starts."
            columns={[
              { key: "provider", label: "Provider", render: (r: any) => <div className="flex items-center gap-2"><Cable className="h-4 w-4 text-[#116fbb]"/><div><p className="font-bold uppercase text-[#082b4d]">{r.provider}</p><p className="text-xs text-slate-500">{r.market} · {r.country}/{r.currency}</p></div></div> },
              { key: "environment", label: "Environment", render: (r: any) => <div><p className="font-semibold capitalize">{r.environment}</p><p className="text-xs text-slate-500">{r.mode}</p></div> },
              { key: "credentials", label: "Credentials", render: (r: any) => <div className="text-xs"><p>{r.has_api_key ? "API key stored" : "No API key"}</p><p>{r.has_public_key ? "Public key stored" : "No public key"}</p></div> },
              {
                key: "active",
                label: "State",
                render: (r: any) => (
                  <div className="flex flex-wrap items-center gap-2">
                    {r.active ? (
                      <span className="inline-flex items-center gap-1 font-bold text-emerald-700">
                        <CheckCircle2 className="h-4 w-4" />
                        Active
                      </span>
                    ) : (
                      <Button
                        size="sm"
                        variant="secondary"
                        disabled={activating || !r.enabled}
                        onClick={() => activate(r.id)}
                      >
                        Activate
                      </Button>
                    )}
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() => setViewingProvider(r)}
                    >
                      <Eye className="mr-1 h-4 w-4" />
                      View
                    </Button>
                  </div>
                ),
              },
            ]}
          />

          <Card>
            <CardHeader><CardTitle className="flex items-center gap-2"><RadioTower className="h-4 w-4"/>Provider-facing URLs</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              {[
                ["Callback URL", sandbox?.callback_url],
                ["Result URL", sandbox?.result_url],
                ["Queue timeout URL", sandbox?.timeout_url],
                ["Redirect / return URL", sandbox?.redirect_url],
              ].map(([label, value]) => <div key={label} className="rounded-xl border bg-slate-50 p-3"><p className="text-xs font-bold uppercase tracking-wide text-slate-500">{label}</p><div className="mt-1 flex items-center gap-2"><code className="min-w-0 flex-1 break-all text-xs text-[#082b4d]">{value || "Configure PUBLIC_API_URL / PUBLIC_APP_URL"}</code><Button size="icon" variant="ghost" disabled={!value} onClick={() => copy(value)}><Copy className="h-4 w-4"/></Button></div></div>)}
              <p className="text-xs leading-5 text-slate-500">A provider timeout is treated as an unknown transaction and reconciled using Query Transaction Status. It is never immediately retried as a new payment.</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle>Recent provider callbacks</CardTitle></CardHeader>
            <CardContent>
              <DataTable rows={callbacks.slice(0, 20)} empty="No provider callbacks received yet." columns={[
                {key:"type",label:"Type",render:(r:any)=><span className="font-semibold capitalize">{r.callback_type}</span>},
                {key:"conversation",label:"Conversation",render:(r:any)=><code className="text-xs">{r.third_party_conversation_id || "—"}</code>},
                {key:"status",label:"Processing",render:(r:any)=><StatusBadge status={r.processing_status}/>},
                {key:"duplicate",label:"Duplicate",render:(r:any)=>r.duplicate ? "Yes" : "No"},
              ]}/>
            </CardContent>
          </Card>
        </div>

        <Card className="h-fit">
          <CardHeader><CardTitle className="flex items-center gap-2"><ShieldCheck className="h-4 w-4"/>Add or update environment</CardTitle></CardHeader>
          <CardContent>
            <form className="grid gap-3 sm:grid-cols-2" onSubmit={submit}>
              <select className="h-11 rounded-xl border bg-white px-3 text-sm" value={form.environment} onChange={(e)=>setForm({...form,environment:e.target.value})}><option value="sandbox">Sandbox</option><option value="production">Production</option></select>
              <select className="h-11 rounded-xl border bg-white px-3 text-sm" value={form.mode} onChange={(e)=>setForm({...form,mode:e.target.value})}><option value="simulator">Simulator</option><option value="live">Live OpenAPI</option></select>
              <Input placeholder="Market" value={form.market} onChange={(e)=>setForm({...form,market:e.target.value})}/>
              <Input placeholder="Country" value={form.country} onChange={(e)=>setForm({...form,country:e.target.value})}/>
              <Input placeholder="Currency" value={form.currency} onChange={(e)=>setForm({...form,currency:e.target.value})}/>
              <Input placeholder="Gateway M-Pesa shortcode" value={form.service_provider_code} onChange={(e)=>setForm({...form,service_provider_code:e.target.value})}/>
              <Input className="sm:col-span-2" placeholder="Registered Origin" value={form.origin} onChange={(e)=>setForm({...form,origin:e.target.value})}/>
              <Input className="sm:col-span-2" type="password" autoComplete="new-password" placeholder="Application API key (encrypted at rest)" value={form.api_key} onChange={(e)=>setForm({...form,api_key:e.target.value})}/>
              <textarea className="min-h-28 rounded-xl border bg-white p-3 text-xs outline-none focus:ring-4 focus:ring-blue-100 sm:col-span-2" placeholder="M-Pesa platform public key" value={form.public_key} onChange={(e)=>setForm({...form,public_key:e.target.value})}/>
              <Input className="sm:col-span-2" placeholder="Callback URL" value={form.callback_url} onChange={(e)=>setForm({...form,callback_url:e.target.value})}/>
              <Input className="sm:col-span-2" placeholder="Result URL" value={form.result_url} onChange={(e)=>setForm({...form,result_url:e.target.value})}/>
              <Input className="sm:col-span-2" placeholder="Queue timeout URL" value={form.timeout_url} onChange={(e)=>setForm({...form,timeout_url:e.target.value})}/>
              <Input className="sm:col-span-2" placeholder="Redirect / return URL" value={form.redirect_url} onChange={(e)=>setForm({...form,redirect_url:e.target.value})}/>
              <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.enabled} onChange={(e)=>setForm({...form,enabled:e.target.checked})}/>Enabled</label>
              <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.active} onChange={(e)=>setForm({...form,active:e.target.checked})}/>Activate after save</label>
              <Button className="sm:col-span-2" disabled={isLoading}>{isLoading ? "Saving…" : "Save gateway provider configuration"}</Button>
            </form>
          </CardContent>
        </Card>
      </div>

      {viewingProvider && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-labelledby="provider-details-title"
          onMouseDown={(event) => {
            if (event.currentTarget === event.target) setViewingProvider(null);
          }}
        >
          <Card className="max-h-[90vh] w-full max-w-3xl overflow-y-auto shadow-2xl">
            <CardHeader className="flex flex-row items-start justify-between gap-4">
              <div>
                <CardTitle id="provider-details-title">M-Pesa provider details</CardTitle>
                <p className="mt-1 text-sm text-slate-500">
                  Read-only configuration for {viewingProvider.environment}. Secrets are never displayed.
                </p>
              </div>
              <Button
                type="button"
                size="icon"
                variant="ghost"
                aria-label="Close provider details"
                onClick={() => setViewingProvider(null)}
              >
                <X className="h-4 w-4" />
              </Button>
            </CardHeader>
            <CardContent className="grid gap-3 sm:grid-cols-2">
              {[
                ["Provider", viewingProvider.provider?.toUpperCase()],
                ["Environment", viewingProvider.environment],
                ["Connection mode", viewingProvider.mode === "live" ? "Live OpenAPI" : "Simulator"],
                ["State", viewingProvider.active ? "Active" : "Inactive"],
                ["Enabled", viewingProvider.enabled ? "Yes" : "No"],
                ["Base URL", viewingProvider.base_url],
                ["Market", viewingProvider.market],
                ["Country", viewingProvider.country],
                ["Currency", viewingProvider.currency],
                ["Gateway M-Pesa shortcode", viewingProvider.service_provider_code || "Not configured"],
                ["Registered Origin", viewingProvider.origin || "Not configured"],
                ["API key", viewingProvider.has_api_key ? "Configured" : "Not configured"],
                ["Platform public key", viewingProvider.has_public_key ? "Configured" : "Not configured"],
                ["Session activation delay", `${viewingProvider.session_activation_seconds ?? 30} seconds`],
                ["Request timeout", `${viewingProvider.request_timeout_seconds ?? 30} seconds`],
              ].map(([label, value]) => (
                <div key={label} className="rounded-xl border bg-slate-50 p-3">
                  <p className="text-xs font-bold uppercase tracking-wide text-slate-500">{label}</p>
                  <p className="mt-1 break-all text-sm font-semibold text-[#082b4d]">{value || "—"}</p>
                </div>
              ))}

              {[
                ["Callback URL", viewingProvider.callback_url],
                ["Result URL", viewingProvider.result_url],
                ["Queue timeout URL", viewingProvider.timeout_url],
                ["Redirect / return URL", viewingProvider.redirect_url],
              ].map(([label, value]) => (
                <div key={label} className="rounded-xl border bg-slate-50 p-3 sm:col-span-2">
                  <p className="text-xs font-bold uppercase tracking-wide text-slate-500">{label}</p>
                  <div className="mt-1 flex items-center gap-2">
                    <code className="min-w-0 flex-1 break-all text-xs text-[#082b4d]">{value || "Not configured"}</code>
                    <Button
                      type="button"
                      size="icon"
                      variant="ghost"
                      disabled={!value}
                      onClick={() => copy(value)}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      )}
    </>
  );
}
