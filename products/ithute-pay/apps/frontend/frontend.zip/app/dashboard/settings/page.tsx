import Link from "next/link";
import { BookOpenText, FlaskConical, KeyRound, Network, ShieldCheck, TerminalSquare } from "lucide-react";
import { PageHeader } from "@/components/dashboard/page-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function Page() {
  return (
    <div className="paybridge-page">
      <PageHeader
        title="Platform settings"
        description="Runtime, security and integration reference for Ithute Pay Bridge."
        actions={
          <>
            <Button asChild variant="secondary"><Link href="/dashboard/documentation"><BookOpenText className="h-4 w-4" />Documentation</Link></Button>
            <Button asChild><Link href="/dashboard/testing"><FlaskConical className="h-4 w-4" />Sandbox test lab</Link></Button>
          </>
        }
      />
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {[
          [ShieldCheck, "Security", "HttpOnly access/refresh cookies, CSRF validation, Argon2 password hashes and encrypted provider credentials."],
          [Network, "Runtime", "FastAPI :8001 · Next.js :3001 · unified application container behind Nginx."],
          [KeyRound, "Merchant auth", "Scoped ipb_test_ / ipb_live_ API keys with hashed-at-rest secrets and idempotency keys."],
          [TerminalSquare, "Developer API", "OpenAPI docs are available at /docs and merchant financial endpoints live under /api/v1."],
        ].map(([Icon, title, text]: any) => (
          <Card key={title}>
            <CardHeader><div className="mb-3 grid h-11 w-11 place-items-center rounded-2xl bg-primary/10 text-primary"><Icon className="h-5 w-5" /></div><CardTitle>{title}</CardTitle></CardHeader>
            <CardContent className="text-sm leading-6 text-muted-foreground">{text}</CardContent>
          </Card>
        ))}
      </div>
      <Card className="mt-6">
        <CardHeader><CardTitle>External access on the VPS</CardTitle></CardHeader>
        <CardContent className="space-y-2 text-sm text-muted-foreground">
          <p>LoanHub remains on <code className="rounded bg-muted px-2 py-1">http://169.255.58.185/</code>.</p>
          <p>Ithute Pay Bridge is configured for <code className="rounded bg-muted px-2 py-1">http://169.255.58.185:8081/</code>.</p>
          <p>The Nginx route keeps the frontend, REST API and WebSocket endpoint on one public gateway origin.</p>
        </CardContent>
      </Card>
    </div>
  );
}
