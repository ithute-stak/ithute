"use client";

import { useMemo, useState } from "react";
import {
  Activity,
  CheckCircle2,
  CircleAlert,
  Eye,
  FlaskConical,
  History,
  Loader2,
  Play,
  RadioTower,
  RotateCcw,
  ShieldCheck,
  Sparkles,
  X,
} from "lucide-react";
import { PageHeader } from "@/components/dashboard/page-header";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { apiError } from "@/lib/api";
import { useAppDispatch, useAppSelector } from "@/store/hooks";
import {
  useRunAllSandboxTestsMutation,
  useRunSandboxTestMutation,
  useSandboxCatalogQuery,
  useSandboxHistoryQuery,
  useTestLiveMpesaSandboxConnectionMutation,
} from "@/store/gateway-api";
import {
  clearSandboxResults,
  recordSandboxResult,
  selectSandboxProduct,
  setSandboxAmount,
  setSandboxCurrency,
  setSandboxExecutionMode,
  setSandboxPhone,
  setSandboxReceiverPartyCode,
  setSandboxScenario,
  type SandboxExecutionMode,
  type SandboxScenario,
} from "@/store/sandbox-lab-slice";

const scenarioLabels: Record<SandboxScenario, string> = {
  success: "Success",
  insufficient_funds: "Insufficient funds",
  processing: "Processing / unknown",
};

const modeLabels: Record<SandboxExecutionMode, { title: string; description: string }> = {
  live_sandbox: {
    title: "Real M-Pesa Sandbox",
    description: "Calls Vodacom M-Pesa OpenAPI over the network using the active Sandbox provider configuration.",
  },
  simulator: {
    title: "Local Simulator",
    description: "Runs deterministic gateway tests locally without contacting M-Pesa.",
  },
};

function ResultBadge({ passed }: { passed: boolean }) {
  return passed ? (
    <Badge className="border-green-200 bg-green-50 text-green-700"><CheckCircle2 className="mr-1 h-3.5 w-3.5" />Passed</Badge>
  ) : (
    <Badge className="border-red-200 bg-red-50 text-red-700"><CircleAlert className="mr-1 h-3.5 w-3.5" />Failed</Badge>
  );
}

export default function SandboxTestingPage() {
  const dispatch = useAppDispatch();
  const form = useAppSelector((state) => state.sandboxLab);
  const { data: catalog, isLoading: catalogLoading, error: catalogError } = useSandboxCatalogQuery();
  const { data: history = [] } = useSandboxHistoryQuery();
  const [testConnection, connectionState] = useTestLiveMpesaSandboxConnectionMutation();
  const [runTest, singleState] = useRunSandboxTestMutation();
  const [runAll, suiteState] = useRunAllSandboxTestsMutation();
  const [connectionResult, setConnectionResult] = useState<any>(null);
  const [lastResult, setLastResult] = useState<any>(null);
  const [suiteResult, setSuiteResult] = useState<any>(null);
  const [viewingActivity, setViewingActivity] = useState<any>(null);
  const [error, setError] = useState("");

  const products = catalog?.products ?? [];
  const selected = useMemo(
    () => products.find((product: any) => product.id === form.selectedProduct) ?? products[0],
    [products, form.selectedProduct],
  );
  const allowedScenarios = (selected?.scenarios ?? ["success"]) as SandboxScenario[];
  const liveInfo = catalog?.live_sandbox;
  const liveSupported = new Set<string>(liveInfo?.supported_products ?? []);
  const isLive = form.executionMode === "live_sandbox";
  const liveReady = Boolean(liveInfo?.ready);
  const scenarioInfo = isLive
    ? liveInfo?.scenario_numbers?.[selected?.id] ?? liveInfo
    : catalog?.simulator;
  const selectedLiveEndpoints: string[] = isLive
    ? liveInfo?.product_endpoints?.[selected?.id] ?? []
    : [];

  function chooseMode(mode: SandboxExecutionMode) {
    dispatch(setSandboxExecutionMode(mode));
    setLastResult(null);
    setSuiteResult(null);
    setConnectionResult(null);
    setError("");
  }

  async function executeConnectionTest() {
    setError("");
    setConnectionResult(null);
    try {
      const result = await testConnection().unwrap();
      setConnectionResult(result);
    } catch (err) {
      setError(apiError(err));
    }
  }

  async function executeSingle() {
    setError("");
    setSuiteResult(null);
    try {
      const result = await runTest({
        product: form.selectedProduct,
        scenario: form.scenario,
        execution_mode: form.executionMode,
        amount: form.amount,
        currency: form.currency,
        phone: form.phone || undefined,
        receiver_party_code: form.receiverPartyCode || undefined,
      }).unwrap();
      setLastResult(result);
      dispatch(recordSandboxResult({
        run_id: result.run_id,
        product: result.product,
        passed: result.passed,
        status: result.status,
        executed_at: result.executed_at,
        result,
      }));
    } catch (err) {
      setError(apiError(err));
    }
  }

  async function executeSuite() {
    setError("");
    setLastResult(null);
    try {
      const result = await runAll({ amount: form.amount, currency: form.currency }).unwrap();
      setSuiteResult(result);
      for (const item of result.results ?? []) {
        dispatch(recordSandboxResult({
          product: item.product,
          passed: item.passed,
          status: item.status,
          executed_at: result.executed_at,
          result: item,
        }));
      }
    } catch (err) {
      setError(apiError(err));
    }
  }

  if (catalogLoading) {
    return <div className="grid min-h-[55vh] place-items-center"><Loader2 className="h-7 w-7 animate-spin text-primary" /></div>;
  }

  return (
    <div className="paybridge-page">
      <PageHeader
        title="M-Pesa sandbox test lab"
        description="Choose between the local simulator and the real Vodacom M-Pesa Sandbox. Live mode is selected by default and shows the provider endpoint, response code, conversation IDs and raw provider response as proof that the request left Pay Bridge."
        actions={
          isLive ? (
            <Button variant="secondary" onClick={executeConnectionTest} disabled={!liveReady || connectionState.isLoading || singleState.isLoading}>
              {connectionState.isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <RadioTower className="h-4 w-4" />}
              Test M-Pesa connection
            </Button>
          ) : (
            <Button onClick={executeSuite} disabled={suiteState.isLoading || singleState.isLoading}>
              {suiteState.isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
              Run simulator success suite
            </Button>
          )
        }
      />

      {(catalogError || error) && (
        <div className="mb-5 rounded-2xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
          {error || apiError(catalogError)}
        </div>
      )}

      <Card className="mb-6">
        <CardHeader><CardTitle>Execution mode</CardTitle></CardHeader>
        <CardContent className="grid gap-3 lg:grid-cols-2">
          {(["live_sandbox", "simulator"] as SandboxExecutionMode[]).map((mode) => {
            const active = form.executionMode === mode;
            const liveMode = mode === "live_sandbox";
            return (
              <button
                key={mode}
                type="button"
                onClick={() => chooseMode(mode)}
                className={`rounded-2xl border p-4 text-left transition ${active ? "border-primary bg-primary/5 shadow-sm ring-1 ring-primary/20" : "border-border/70 bg-card hover:border-primary/40"}`}
              >
                <div className="flex items-center justify-between gap-3">
                  <p className="font-black text-foreground">{modeLabels[mode].title}</p>
                  {liveMode ? (
                    <Badge className={liveReady ? "border-green-200 bg-green-50 text-green-700" : "border-red-200 bg-red-50 text-red-700"}>
                      {liveReady ? "Ready" : "Not ready"}
                    </Badge>
                  ) : <Badge>Local</Badge>}
                </div>
                <p className="mt-2 text-sm leading-6 text-muted-foreground">{modeLabels[mode].description}</p>
              </button>
            );
          })}
        </CardContent>
      </Card>

      {isLive && !liveReady && (
        <div className="mb-6 rounded-2xl border border-red-200 bg-red-50 p-4 text-sm leading-6 text-red-800">
          <strong>Live sandbox is not ready.</strong> Missing: {(liveInfo?.missing ?? ["active Sandbox Live OpenAPI provider"]).join(", ")}.
        </div>
      )}

      <div className="mb-6 grid gap-4 lg:grid-cols-3">
        <Card>
          <CardHeader><CardTitle className="flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-[var(--brand-green)]" />Provider path</CardTitle></CardHeader>
          <CardContent className="text-sm leading-6 text-muted-foreground">
            <p className="font-bold text-foreground">{isLive ? "Vodacom M-Pesa OpenAPI" : "Ithute Pay Bridge Simulator"}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <Badge>{isLive ? "sandbox" : "local"}</Badge>
              <Badge>{isLive ? "live" : "simulator"}</Badge>
              {isLive && liveInfo?.market && <Badge>{liveInfo.market}</Badge>}
            </div>
            {isLive && (selectedLiveEndpoints.length ? (
              <div className="mt-3 space-y-1">
                {selectedLiveEndpoints.map((endpoint) => <code key={endpoint} className="block break-all text-[10px] text-primary">{endpoint}</code>)}
              </div>
            ) : (
              <p className="mt-3 text-xs text-muted-foreground">Gateway-only validation; no M-Pesa endpoint is called.</p>
            ))}
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="flex items-center gap-2"><FlaskConical className="h-4 w-4 text-primary" />Scenario numbers</CardTitle></CardHeader>
          <CardContent className="text-center text-xs">
            {isLive && selected?.id === "transfer" ? (
              <div className="rounded-xl border bg-muted/30 p-3"><p className="font-black text-green-700">B2B receiver code</p><code>{form.receiverPartyCode || "000001"}</code></div>
            ) : isLive && selected?.live_mode === "gateway_only" ? (
              <div className="rounded-xl border bg-muted/30 p-3"><p className="font-black text-foreground">No provider test number</p><p className="mt-1 text-muted-foreground">This check stays inside Ithute Pay Bridge.</p></div>
            ) : (
              <div className="grid grid-cols-3 gap-2">
                <div className="rounded-xl border bg-muted/30 p-2"><p className="font-black text-green-700">Success</p><code>{scenarioInfo?.success_phone ?? "—"}</code></div>
                <div className="rounded-xl border bg-muted/30 p-2"><p className="font-black text-red-700">Funds</p><code>{scenarioInfo?.insufficient_funds_phone ?? "—"}</code></div>
                <div className="rounded-xl border bg-muted/30 p-2"><p className="font-black text-amber-700">Timeout</p><code>{scenarioInfo?.processing_phone ?? "—"}</code></div>
              </div>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="flex items-center gap-2"><Activity className="h-4 w-4 text-primary" />Live configuration</CardTitle></CardHeader>
          <CardContent className="text-sm leading-6 text-muted-foreground">
            {isLive ? (
              <>
                <p><strong className="text-foreground">Market:</strong> {liveInfo?.market ?? "—"}</p>
                <p><strong className="text-foreground">Country:</strong> {liveInfo?.country ?? "—"}</p>
                <p><strong className="text-foreground">Currency:</strong> {liveInfo?.currency ?? "—"}</p>
                <p><strong className="text-foreground">Shortcode:</strong> {liveInfo?.service_provider_code ?? "Not configured"}</p>
                <p className="break-all"><strong className="text-foreground">Origin:</strong> {liveInfo?.origin ?? "Not configured"}</p>
              </>
            ) : <><strong className="text-2xl font-black text-foreground">{products.length}</strong><p>functional modules are available in the local simulator suite.</p></>}
          </CardContent>
        </Card>
      </div>

      {connectionResult && (
        <Card className="mb-6">
          <CardHeader><CardTitle className="flex items-center gap-2"><RadioTower className="h-4 w-4" />Live SessionKey connection result</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between gap-3">
              <p className="text-sm text-muted-foreground">{connectionResult.endpoint}</p>
              <ResultBadge passed={Boolean(connectionResult.ok)} />
            </div>
            <pre className="max-h-[360px] overflow-auto rounded-2xl bg-slate-950 p-4 text-xs leading-6 text-slate-100">{JSON.stringify(connectionResult, null, 2)}</pre>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-6 2xl:grid-cols-[minmax(0,1.15fr)_minmax(400px,.85fr)]">
        <div className="space-y-5">
          <Card>
            <CardHeader><CardTitle>Choose a product</CardTitle></CardHeader>
            <CardContent>
              <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
                {products.map((product: any) => {
                  const active = product.id === form.selectedProduct;
                  const disabled = isLive && !liveSupported.has(product.id);
                  return (
                    <button
                      type="button"
                      key={product.id}
                      disabled={disabled}
                      onClick={() => dispatch(selectSandboxProduct(product.id))}
                      className={`rounded-2xl border p-4 text-left transition ${disabled ? "cursor-not-allowed opacity-45" : active ? "border-primary bg-primary/5 shadow-sm ring-1 ring-primary/20" : "border-border/70 bg-card hover:border-primary/30 hover:bg-muted/20"}`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <p className="font-black text-foreground">{product.name}</p>
                        {isLive && liveSupported.has(product.id) && (
                          product.live_mode === "gateway_only" ? (
                            <Badge>Gateway</Badge>
                          ) : product.live_mode === "live_backed" ? (
                            <Badge className="border-blue-200 bg-blue-50 text-blue-700">Live-backed</Badge>
                          ) : (
                            <Badge className="border-green-200 bg-green-50 text-green-700">Live M-Pesa</Badge>
                          )
                        )}
                      </div>
                      <p className="mt-1 line-clamp-2 text-xs leading-5 text-muted-foreground">{product.summary}</p>
                      <code className="mt-3 block truncate text-[10px] text-primary">{product.endpoint}</code>
                    </button>
                  );
                })}
              </div>
              {isLive && <p className="mt-3 text-xs text-muted-foreground">All gateway products are selectable in live sandbox mode. Direct provider products call M-Pesa OpenAPI; live-backed products execute their gateway workflow around a real sandbox transaction; webhook signing remains gateway-only because it has no M-Pesa API call.</p>}
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle>{selected?.name ?? "Product"} test configuration</CardTitle></CardHeader>
            <CardContent className="space-y-5">
              <div>
                <label className="mb-2 block text-xs font-black uppercase tracking-wider text-muted-foreground">Scenario</label>
                <div className="flex flex-wrap gap-2">
                  {allowedScenarios.map((scenario) => (
                    <button
                      type="button"
                      key={scenario}
                      onClick={() => dispatch(setSandboxScenario(scenario))}
                      className={`rounded-xl border px-3 py-2 text-xs font-bold transition ${form.scenario === scenario ? "border-primary bg-primary text-primary-foreground" : "bg-card text-muted-foreground hover:border-primary/40"}`}
                    >
                      {scenarioLabels[scenario]}
                    </button>
                  ))}
                </div>
              </div>

              <div className="form-grid">
                <label className="grid gap-2 text-xs font-black uppercase tracking-wider text-muted-foreground">
                  Amount
                  <Input type="number" min="0.01" step="0.01" value={form.amount} onChange={(e) => dispatch(setSandboxAmount(e.target.value))} />
                </label>
                <label className="grid gap-2 text-xs font-black uppercase tracking-wider text-muted-foreground">
                  Currency
                  <Input maxLength={3} value={form.currency} onChange={(e) => dispatch(setSandboxCurrency(e.target.value))} />
                </label>
                <label className="grid gap-2 text-xs font-black uppercase tracking-wider text-muted-foreground">
                  Phone override
                  <Input placeholder={isLive ? "Blank = M-Pesa sandbox scenario number" : "Blank = local simulator scenario number"} value={form.phone} onChange={(e) => dispatch(setSandboxPhone(e.target.value))} />
                </label>
                <label className="grid gap-2 text-xs font-black uppercase tracking-wider text-muted-foreground">
                  Receiver party code
                  <Input disabled={form.selectedProduct !== "transfer"} value={form.receiverPartyCode} onChange={(e) => dispatch(setSandboxReceiverPartyCode(e.target.value))} />
                </label>
              </div>

              {isLive ? (
                <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm leading-6 text-amber-900">
                  <strong>REAL M-PESA SANDBOX:</strong> provider-backed products send actual HTTPS requests to the configured Vodacom M-Pesa sandbox. Production is always refused. Gateway-only checks are clearly marked and do not claim network traffic.
                </div>
              ) : (
                <div className="rounded-2xl border border-blue-200 bg-blue-50 p-4 text-sm leading-6 text-blue-900">
                  <strong>LOCAL SIMULATOR:</strong> no provider network request is sent. Use this mode for fast deterministic gateway, ledger, webhook and settlement tests.
                </div>
              )}

              <Button onClick={executeSingle} disabled={singleState.isLoading || suiteState.isLoading || (isLive && !liveReady)} className="w-full sm:w-auto">
                {singleState.isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : isLive ? <RadioTower className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                {isLive ? (selected?.live_mode === "gateway_only" ? "Run gateway-only check" : "Send to real M-Pesa Sandbox") : `Run ${selected?.name ?? "test"}`}
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-5">
          <Card>
            <CardHeader><CardTitle>Latest result</CardTitle></CardHeader>
            <CardContent>
              {!lastResult && !suiteResult && <div className="grid min-h-52 place-items-center text-center text-sm text-muted-foreground"><div><FlaskConical className="mx-auto mb-3 h-8 w-8 text-primary/60" /><p>{isLive ? "Test the SessionKey connection or send a real sandbox collection to see provider proof here." : "Run one product or the simulator suite to see validation details."}</p></div></div>}
              {lastResult && (
                <div className="space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-2"><div><p className="font-black capitalize text-foreground">{lastResult.product?.replaceAll("_", " ")}</p><p className="text-xs text-muted-foreground">{lastResult.duration_ms} ms · {lastResult.scenario} · {lastResult.workspace?.execution_mode ?? form.executionMode}</p></div><ResultBadge passed={lastResult.passed} /></div>
                  {lastResult.checks?.network_request_sent && (
                    <div className="rounded-xl border border-green-200 bg-green-50 p-3 text-sm text-green-800"><strong>Network proof:</strong> request targeted <code className="break-all">{lastResult.checks.endpoint ?? lastResult.checks.endpoints?.join(" → ") ?? "M-Pesa sandbox"}</code></div>
                  )}
                  <div className="grid grid-cols-2 gap-2 text-sm"><div className="rounded-xl border p-3"><p className="text-xs text-muted-foreground">Actual</p><p className="mt-1 font-black">{String(lastResult.status)}</p></div><div className="rounded-xl border p-3"><p className="text-xs text-muted-foreground">Expected</p><p className="mt-1 font-black">{String(lastResult.expected_status)}</p></div></div>
                  <pre className="max-h-[520px] overflow-auto rounded-2xl bg-slate-950 p-4 text-xs leading-6 text-slate-100">{JSON.stringify({ resource: lastResult.resource, checks: lastResult.checks }, null, 2)}</pre>
                </div>
              )}
              {suiteResult && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between gap-3"><div><p className="font-black text-foreground">Simulator success suite</p><p className="text-xs text-muted-foreground">{suiteResult.total} products executed locally</p></div><Badge className={suiteResult.failed ? "border-amber-200 bg-amber-50 text-amber-800" : "border-green-200 bg-green-50 text-green-700"}>{suiteResult.passed}/{suiteResult.total} passed</Badge></div>
                  <div className="space-y-2">{(suiteResult.results ?? []).map((item: any) => <div key={item.product} className="flex items-center justify-between gap-3 rounded-xl border border-border/70 p-3"><div><p className="text-sm font-bold capitalize">{item.product.replaceAll("_", " ")}</p><p className="text-xs text-muted-foreground">{item.status}{item.error ? ` · ${item.error}` : ""}</p></div><ResultBadge passed={item.passed} /></div>)}</div>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader><div className="flex items-center justify-between gap-3"><CardTitle className="flex items-center gap-2"><History className="h-4 w-4" />Recent test activity</CardTitle><Button variant="ghost" size="sm" onClick={() => dispatch(clearSandboxResults())}><RotateCcw className="h-3.5 w-3.5" />Clear local</Button></div></CardHeader>
            <CardContent className="space-y-2">
              {[...form.recentResults.slice(0, 6), ...history.slice(0, 4).map((row: any) => ({
                product: row.metadata?.product ?? "full suite",
                passed: row.metadata?.all_passed ?? (typeof row.metadata?.passed === "boolean" ? row.metadata.passed : true),
                status: row.metadata?.status ?? (row.metadata?.total ? `${row.metadata.passed}/${row.metadata.total} passed` : row.action),
                executed_at: row.created_at,
                result: row.metadata?.result ?? row.metadata?.results ?? row.metadata ?? row,
              }))].slice(0, 8).map((item: any, index: number) => (
                <div key={`${item.run_id ?? item.executed_at ?? index}-${index}`} className="flex items-center justify-between gap-3 rounded-xl border border-border/60 bg-muted/15 p-3">
                  <div className="min-w-0 flex-1"><p className="truncate text-sm font-bold capitalize">{String(item.product).replaceAll("_", " ")}</p><p className="truncate text-xs text-muted-foreground">{item.status ?? "completed"}</p></div>
                  <div className="flex items-center gap-2">
                    <ResultBadge passed={Boolean(item.passed)} />
                    <Button type="button" variant="ghost" size="sm" onClick={() => setViewingActivity(item.result ?? item)}>
                      <Eye className="h-3.5 w-3.5" />View
                    </Button>
                  </div>
                </div>
              ))}
              {!form.recentResults.length && !history.length && <p className="py-6 text-center text-sm text-muted-foreground">No sandbox test history yet.</p>}
            </CardContent>
          </Card>
        </div>
      </div>

      {viewingActivity && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/55 p-4 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-labelledby="sandbox-activity-json-title"
          onMouseDown={(event) => { if (event.currentTarget === event.target) setViewingActivity(null); }}
        >
          <Card className="max-h-[90vh] w-full max-w-4xl overflow-hidden shadow-2xl">
            <CardHeader>
              <div className="flex items-start justify-between gap-4">
                <div>
                  <CardTitle id="sandbox-activity-json-title">Returned JSON body</CardTitle>
                  <p className="mt-1 text-xs text-muted-foreground">Saved test response and provider proof for this activity.</p>
                </div>
                <Button type="button" variant="ghost" size="sm" onClick={() => setViewingActivity(null)} aria-label="Close JSON viewer">
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <pre className="max-h-[70vh] overflow-auto rounded-2xl bg-slate-950 p-4 text-xs leading-6 text-slate-100">{JSON.stringify(viewingActivity, null, 2)}</pre>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
