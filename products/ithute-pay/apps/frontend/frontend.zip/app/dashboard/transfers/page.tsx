"use client";
import { DataTable } from "@/components/dashboard/data-table";
import { PageHeader } from "@/components/dashboard/page-header";
import { StatusBadge } from "@/components/dashboard/status-badge";
import { useAdminReversalsQuery, useAdminTransfersQuery } from "@/store/gateway-api";

export default function TransfersPage() {
  const { data: transfers = [], isLoading } = useAdminTransfersQuery();
  const { data: reversals = [] } = useAdminReversalsQuery();
  return <div className="space-y-6">
    <PageHeader title="Business transfers" description="B2B provider transfers and confirmed compensating reversals across merchant applications." />
    <DataTable rows={transfers} empty={isLoading ? "Loading transfers…" : "No business transfers yet."} columns={[
      { key: "id", label: "Transfer", render: (row: any) => <div><p className="font-bold text-[#082b4d]">{row.id}</p><p className="text-xs text-slate-500">{row.reference}</p></div> },
      { key: "amount", label: "Amount", render: (row: any) => <span className="font-black">{row.currency} {row.amount}</span> },
      { key: "provider", label: "Provider", render: (row: any) => row.provider },
      { key: "receiver", label: "Receiver", render: (row: any) => row.receiver_party_code },
      { key: "status", label: "Status", render: (row: any) => <StatusBadge status={row.status} /> },
      { key: "created", label: "Created", render: (row: any) => new Date(row.created_at).toLocaleString() },
    ]} />
    <div>
      <h2 className="mb-3 text-lg font-black text-[#082b4d]">Recent reversals</h2>
      <DataTable rows={reversals} empty="No reversals recorded." columns={[
        { key: "id", label: "Reversal", render: (row: any) => <span className="font-bold">{row.id}</span> },
        { key: "amount", label: "Amount", render: (row: any) => row.amount ?? "Full" },
        { key: "reason", label: "Reason", render: (row: any) => row.reason },
        { key: "status", label: "Status", render: (row: any) => <StatusBadge status={row.status} /> },
        { key: "created", label: "Created", render: (row: any) => new Date(row.created_at).toLocaleString() },
      ]} />
    </div>
  </div>;
}
