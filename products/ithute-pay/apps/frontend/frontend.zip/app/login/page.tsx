"use client";

import { FormEvent, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowRight, BookOpenText, CheckCircle2, Loader2, ShieldCheck } from "lucide-react";
import { useLoginMutation } from "@/store/gateway-api";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { apiError } from "@/lib/api";

export default function LoginPage() {
  const router = useRouter();
  const [login, { isLoading }] = useLoginMutation();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  async function submit(event: FormEvent) {
    event.preventDefault(); setError("");
    try { await login({ email, password }).unwrap(); router.replace("/dashboard"); }
    catch (err) { setError(apiError(err)); }
  }

  return <main className="min-h-screen bg-[#f4f8fb] lg:grid lg:grid-cols-[1.15fr_.85fr]">
    <section className="relative hidden overflow-hidden bg-[#062b4d] p-12 text-white lg:flex lg:flex-col lg:justify-between">
      <div className="absolute -right-20 -top-20 h-96 w-96 rounded-full bg-[#116fbb]/20 blur-2xl"/><div className="absolute bottom-20 left-10 h-72 w-72 rounded-full bg-[#45a827]/15 blur-3xl"/>
      <img src="/brand/ithute-pay-bridge-horizontal.svg" className="relative h-auto w-[410px] rounded-2xl bg-white p-3" alt="Ithute Pay Bridge" />
      <div className="relative max-w-2xl"><p className="text-sm font-black uppercase tracking-[.28em] text-green-300">Connected payment infrastructure</p><h1 className="mt-5 text-5xl font-black leading-[1.08]">Move money safely. Reconcile every cent. Connect every system.</h1><p className="mt-6 max-w-xl text-base leading-7 text-slate-300">A standalone gateway for collections, payouts, M-Pesa integration, signed webhooks, direct debit mandates, settlements and double-entry accounting.</p><div className="mt-8 grid gap-3 sm:grid-cols-2">{["Idempotent financial APIs","HttpOnly platform authentication","Realtime WebSocket operations","Immutable journal accounting"].map(x=><div key={x} className="flex items-center gap-2 text-sm text-slate-200"><CheckCircle2 className="h-4 w-4 text-green-400"/>{x}</div>)}</div></div>
      <p className="relative text-xs text-slate-400">Ithute Solutions · Secure infrastructure for connected businesses</p>
    </section>
    <section className="grid min-h-screen place-items-center p-5 sm:p-8">
      <div className="w-full max-w-md"><img src="/brand/ithute-pay-bridge-horizontal.svg" className="mx-auto mb-6 w-[310px] lg:hidden" alt="Ithute Pay Bridge"/><Card className="border-0 shadow-[0_24px_70px_rgba(6,43,77,.12)]"><CardContent className="p-6 sm:p-8"><div className="mb-7"><div className="mb-4 grid h-12 w-12 place-items-center rounded-2xl bg-blue-50 text-[#116fbb]"><ShieldCheck className="h-6 w-6"/></div><h2 className="text-2xl font-black text-[#082b4d]">Platform sign in</h2><p className="mt-2 text-sm leading-6 text-slate-500">Access the operations and developer administration console.</p></div><form className="space-y-4" onSubmit={submit}><div><label className="mb-1.5 block text-sm font-bold text-slate-700">Email</label><Input required autoComplete="email" type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="admin@company.com"/></div><div><label className="mb-1.5 block text-sm font-bold text-slate-700">Password</label><Input required autoComplete="current-password" type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="••••••••••••"/></div>{error && <div className="rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error}</div>}<Button className="mt-2 w-full" size="lg" disabled={isLoading}>{isLoading ? <Loader2 className="h-4 w-4 animate-spin"/> : <ArrowRight className="h-4 w-4"/>}{isLoading ? "Signing in…" : "Sign in securely"}</Button></form><div className="my-5 flex items-center gap-3"><div className="h-px flex-1 bg-slate-200"/><span className="text-[10px] font-black uppercase tracking-[.18em] text-slate-400">or explore first</span><div className="h-px flex-1 bg-slate-200"/></div><Button asChild variant="secondary" size="lg" className="w-full"><Link href="/documentation"><BookOpenText className="h-4 w-4"/>Visitor documentation</Link></Button><p className="mt-5 text-center text-xs leading-5 text-slate-400">Documentation is public. Platform operations remain protected. Access tokens are stored in HttpOnly cookies and protected with CSRF validation.</p></CardContent></Card></div>
    </section>
  </main>;
}
