import { cn } from "@/lib/utils";

export type Column<T> = { key: string; label: string; className?: string; render: (row: T) => React.ReactNode };

export function DataTable<T>({ rows, columns, empty = "No records yet." }: { rows: T[]; columns: Column<T>[]; empty?: string }) {
  if (!rows.length) {
    return <div className="rounded-2xl border border-dashed border-border bg-card/70 p-10 text-center text-sm text-muted-foreground">{empty}</div>;
  }
  return (
    <div className="overflow-hidden rounded-2xl border border-border/70 bg-card/90 shadow-sm">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[760px] border-collapse text-left text-sm">
          <thead className="bg-muted/45">
            <tr>{columns.map((column) => <th key={column.key} className={cn("border-b border-border/70 px-4 py-3 text-xs font-black uppercase tracking-[.08em] text-muted-foreground", column.className)}>{column.label}</th>)}</tr>
          </thead>
          <tbody>
            {rows.map((row, index) => (
              <tr key={index} className="border-b border-border/60 transition last:border-0 hover:bg-muted/25">
                {columns.map((column) => <td key={column.key} className={cn("px-4 py-3 align-middle text-foreground/85", column.className)}>{column.render(row)}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
