"use client";

import Link from "next/link";
import { useEffect } from "react";
import { usePathname } from "next/navigation";
import {
  Activity,
  ArrowLeftRight,
  Banknote,
  BookOpenText,
  Building2,
  Cable,
  BadgeDollarSign,
  Route,
  Send,
  ChevronLeft,
  ChevronRight,
  FlaskConical,
  KeyRound,
  Landmark,
  LayoutDashboard,
  Repeat2,
  ScrollText,
  Settings,
  ShieldCheck,
  WalletCards,
  Webhook,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAppDispatch, useAppSelector } from "@/store/hooks";
import { setSidebarCollapsed, toggleSidebar } from "@/store/ui-slice";

const items = [
  ["/dashboard", "Overview", LayoutDashboard],
  ["/dashboard/payments", "Collections", WalletCards],
  ["/dashboard/payouts", "Payouts", Banknote],
  ["/dashboard/transactions", "Transactions", ArrowLeftRight],
  ["/dashboard/transfers", "Business transfers", ArrowLeftRight],
  ["/dashboard/authorizations", "Authorizations", ShieldCheck],
  ["/dashboard/mandates", "Direct debit", Repeat2],
  ["/dashboard/finance", "Accounting", Landmark],
  ["/dashboard/reconciliation", "Reconciliation", Activity],
  ["/dashboard/merchants", "Merchants", Building2],
  ["/dashboard/routing", "Client routing", Route],
  ["/dashboard/fees", "Fees & packages", BadgeDollarSign],
  ["/dashboard/settlements", "Settlements", Send],
  ["/dashboard/applications", "Applications & keys", KeyRound],
  ["/dashboard/providers", "Providers", Cable],
  ["/dashboard/checkout", "Checkout & links", WalletCards],
  ["/dashboard/webhooks", "Webhooks & events", Webhook],
  ["/dashboard/testing", "Sandbox test lab", FlaskConical],
  ["/dashboard/documentation", "Documentation", BookOpenText],
  ["/dashboard/audit", "Audit trail", ScrollText],
  ["/dashboard/settings", "Settings", Settings],
] as const;

export function SidebarContent({
  onNavigate,
  collapsed = false,
}: {
  onNavigate?: () => void;
  collapsed?: boolean;
}) {
  const path = usePathname();

  return (
    <div className="flex h-full flex-col border-r border-sidebar-border bg-sidebar/95 text-sidebar-foreground shadow-[10px_0_40px_rgba(6,43,85,.06)] backdrop-blur-xl">
      <div className={cn("border-b border-sidebar-border px-3 py-4", collapsed ? "px-2" : "px-4")}>
        <Link
          href="/dashboard"
          onClick={onNavigate}
          className={cn("flex items-center", collapsed ? "justify-center" : "gap-3")}
          title="Ithute Pay Bridge"
        >
          <img
            src="/brand/ithute-pay-bridge-icon.svg"
            alt="Ithute Pay Bridge"
            className="h-11 w-11 shrink-0 rounded-2xl border border-sidebar-border bg-white p-1 shadow-sm"
          />
          {!collapsed && (
            <div className="min-w-0">
              <p className="truncate text-sm font-black text-sidebar-foreground">Ithute Pay Bridge</p>
              <p className="text-[10px] font-extrabold uppercase tracking-[.18em] text-primary">Ithute Solutions</p>
            </div>
          )}
        </Link>
      </div>

      <nav className={cn("flex-1 space-y-1 overflow-y-auto py-3", collapsed ? "px-2" : "px-3")}>
        {items.map(([href, label, Icon]) => {
          const active = href === "/dashboard" ? path === href : path.startsWith(href);
          return (
            <Link
              key={href}
              href={href}
              onClick={onNavigate}
              title={collapsed ? label : undefined}
              aria-label={label}
              className={cn(
                "group flex items-center rounded-xl text-sm font-semibold transition-all duration-200",
                collapsed ? "h-11 justify-center px-2" : "gap-3 px-3 py-2.5",
                active
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "text-muted-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
              )}
            >
              <Icon className={cn("h-4 w-4 shrink-0 transition-transform group-hover:scale-105", collapsed && "h-[18px] w-[18px]")} />
              {!collapsed && <span className="truncate">{label}</span>}
            </Link>
          );
        })}
      </nav>

      <div className={cn("border-t border-sidebar-border", collapsed ? "p-2" : "p-4")}>
        {collapsed ? (
          <div className="grid place-items-center" title="Secure gateway console">
            <ShieldCheck className="h-5 w-5 text-[var(--brand-green)]" />
          </div>
        ) : (
          <div className="text-[11px] leading-5 text-muted-foreground">
            <div className="flex items-center gap-2 font-semibold text-foreground">
              <ShieldCheck className="h-4 w-4 text-[var(--brand-green)]" />
              Secure gateway console
            </div>
            <p className="mt-1">FastAPI 8001 · Next.js 3001</p>
          </div>
        )}
      </div>
    </div>
  );
}

export function Sidebar() {
  const dispatch = useAppDispatch();
  const collapsed = useAppSelector((state) => state.ui.sidebarCollapsed);

  useEffect(() => {
    const saved = window.localStorage.getItem("ipb-sidebar-collapsed");
    if (saved === "true" || saved === "false") {
      dispatch(setSidebarCollapsed(saved === "true"));
    }
  }, [dispatch]);

  const toggle = () => {
    const next = !collapsed;
    dispatch(toggleSidebar());
    window.localStorage.setItem("ipb-sidebar-collapsed", String(next));
  };

  return (
    <aside
      className={cn(
        "sticky top-0 hidden h-screen shrink-0 transition-[width] duration-300 lg:block",
        collapsed ? "w-[84px]" : "w-[278px]",
      )}
    >
      <SidebarContent collapsed={collapsed} />
      <button
        type="button"
        onClick={toggle}
        aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
        title={collapsed ? "Expand sidebar" : "Collapse sidebar"}
        className="absolute -right-3 top-[74px] z-20 grid h-7 w-7 place-items-center rounded-full border border-sidebar-border bg-card text-muted-foreground shadow-md transition hover:border-primary/40 hover:text-primary"
      >
        {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
      </button>
    </aside>
  );
}
