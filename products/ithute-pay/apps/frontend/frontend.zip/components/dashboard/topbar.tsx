"use client";

import * as Dialog from "@radix-ui/react-dialog";
import { Bell, Menu, Radio, UserCircle2, X } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { SidebarContent } from "./sidebar";
import { Button } from "@/components/ui/button";
import { useAppSelector } from "@/store/hooks";
import { useLogoutMutation, useMeQuery } from "@/store/gateway-api";

export function Topbar() {
  const [open, setOpen] = useState(false);
  const router = useRouter();
  const { data: user } = useMeQuery();
  const [logout] = useLogoutMutation();
  const realtime = useAppSelector((s) => s.realtime);
  const doLogout = async () => {
    try {
      await logout().unwrap();
    } finally {
      router.replace("/login");
    }
  };

  return (
    <header className="sticky top-0 z-30 border-b border-border/70 bg-background/88 backdrop-blur-xl">
      <div className="flex h-16 items-center gap-3 px-4 sm:px-6 lg:px-8">
        <Dialog.Root open={open} onOpenChange={setOpen}>
          <Dialog.Trigger asChild>
            <Button variant="ghost" size="icon" className="lg:hidden" aria-label="Open navigation">
              <Menu className="h-5 w-5" />
            </Button>
          </Dialog.Trigger>
          <Dialog.Portal>
            <Dialog.Overlay className="fixed inset-0 z-50 bg-[var(--brand-navy)]/45 backdrop-blur-sm" />
            <Dialog.Content className="fixed inset-y-0 left-0 z-50 w-[300px] shadow-2xl">
              <Dialog.Title className="sr-only">Navigation</Dialog.Title>
              <SidebarContent onNavigate={() => setOpen(false)} />
              <Dialog.Close className="absolute right-3 top-3 grid h-9 w-9 place-items-center rounded-xl border bg-card/90 text-foreground shadow-sm">
                <X className="h-4 w-4" />
              </Dialog.Close>
            </Dialog.Content>
          </Dialog.Portal>
        </Dialog.Root>

        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-black text-[var(--brand-navy)]">Payment infrastructure console</p>
          <p className="hidden text-xs text-muted-foreground sm:block">Collections, payouts, accounting, providers and developer integrations</p>
        </div>

        <div className="hidden items-center gap-2 rounded-full border border-border/70 bg-card/80 px-3 py-1.5 text-xs font-semibold shadow-xs sm:flex">
          <Radio className={`h-3.5 w-3.5 ${realtime.connected ? "text-[var(--brand-green)]" : "text-amber-500"}`} />
          {realtime.connected ? "Live" : "Connecting"}
        </div>

        <div className="relative hidden sm:block">
          <Button variant="ghost" size="icon" aria-label="Realtime notifications">
            <Bell className="h-5 w-5" />
          </Button>
          {realtime.unread > 0 && (
            <span className="absolute right-0 top-0 grid h-5 min-w-5 place-items-center rounded-full bg-destructive px-1 text-[10px] font-bold text-white">
              {Math.min(realtime.unread, 99)}
            </span>
          )}
        </div>

        <div className="hidden text-right md:block">
          <p className="max-w-[190px] truncate text-xs font-bold text-[var(--brand-navy)]">{user?.full_name || "Platform user"}</p>
          <p className="text-[11px] capitalize text-muted-foreground">{user?.role?.replaceAll("_", " ")}</p>
        </div>

        <Button variant="secondary" size="sm" onClick={doLogout}>
          <UserCircle2 className="h-4 w-4" />
          <span className="hidden sm:inline">Sign out</span>
        </Button>
      </div>
    </header>
  );
}
