import { createSlice, type PayloadAction } from "@reduxjs/toolkit";

export type DocumentationTab = "admin" | "consumer" | "testing";

export type UiState = {
  sidebarCollapsed: boolean;
  documentationTab: DocumentationTab;
};

const initialState: UiState = {
  sidebarCollapsed: false,
  documentationTab: "admin",
};

const uiSlice = createSlice({
  name: "ui",
  initialState,
  reducers: {
    setSidebarCollapsed(state, action: PayloadAction<boolean>) {
      state.sidebarCollapsed = action.payload;
    },
    toggleSidebar(state) {
      state.sidebarCollapsed = !state.sidebarCollapsed;
    },
    setDocumentationTab(state, action: PayloadAction<DocumentationTab>) {
      state.documentationTab = action.payload;
    },
  },
});

export const { setSidebarCollapsed, toggleSidebar, setDocumentationTab } = uiSlice.actions;
export default uiSlice.reducer;
